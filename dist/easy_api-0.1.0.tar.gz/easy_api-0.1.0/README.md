# Easy API

Easy API é uma biblioteca simples para construção de APIs usando FastAPI e SQLAlchemy.

## Instalação

Para instalar, execute o seguinte comando:

```bash
pip install easy-api
